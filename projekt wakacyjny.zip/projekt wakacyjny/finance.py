import json

class Finance:
    def __init__(self, balance):
        self.balance = balance

    def update_balance(self, amount):
        self.balance += amount

    def to_dict(self):
        return {"balance": self.balance}

def load_finance(filepath="data/finance.json"):
    with open(filepath, "r") as file:
        return Finance(**json.load(file))

def save_finance(finance, filepath="data/finance.json"):
    with open(filepath, "w") as file:
        json.dump(finance.to_dict(), file, indent=4)