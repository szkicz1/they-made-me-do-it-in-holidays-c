from user import load_users, save_users, Admin, Employe
from product import load_products, save_products
from finance import load_finance, save_finance
from report import generate_report

def main():
    users = load_users()
    products = load_products()
    finance = load_finance()

    # Logowanie jako admin lub pracownik
    current_user = None
    username = input("Wprowadź nazwę użytkownika: ")
    for user in users:
        if user.username == username:
            current_user = user
            break

    if not current_user:
        print("Użytkownik nie znaleziony.")
        return

    # Jeśli zalogowany użytkownik jest Adminem
    if isinstance(current_user, Admin):
        print("Zalogowano jako Admin.")
        action = input("Czy chcesz zmodyfikować dane użytkowników? (tak/nie): ")
        if action.lower() == "tak":
            username_to_modify = input("Podaj nazwę użytkownika do modyfikacji: ")
            new_role = input("Nowa rola: ")
            for user in users:
                if user.username == username_to_modify:
                    current_user.modify_user(user, {"role": new_role})
                    save_users(users)
                    break
    # Opcje dla pracownika
    elif isinstance(current_user, Employe):
        print("Zalogowano jako Pracownik.")
        action = input("Czy chcesz zamówić czy sprzedać produkt? (zamów/sprzedaj): ")
        product_name = input("Podaj nazwę produktu: ")
        quantity = int(input("Podaj ilość: "))
        if action.lower() == "zamów":
            result = current_user.order_product(product_name, quantity)
            print(result)
        elif action.lower() == "sprzedaj":
            result = current_user.sell_product(product_name, quantity)
            print(result)

    # Generowanie raportu
    generate_report()
    print("Raport został wygenerowany.")

if __name__ == "__main__":
    main()