import json
from product import Product, load_products, save_products
from finance import load_finance, save_finance

class User:
    def __init__(self, username, role="employee"):
        self.username = username
        self.role = role

    def to_dict(self):
        return {"username": self.username, "role": self.role}

class Admin(User):
    def __init__(self, username, role="admin"):
        super().__init__(username, role)

    def modify_user(self, user, new_data):
        user.username = new_data.get("username", user.username)
        user.role = new_data.get("role", user.role)

class Employe(User):
    def __init__(self, username, role="employee"):
        super().__init__(username, role)

    def order_product(self, product_name, quantity):
        products = load_products()
        finance = load_finance()
        for product in products:
            if product.name == product_name:
                total_cost = product.price * quantity
                if finance.balance >= total_cost:
                    product.update_stock(quantity)
                    finance.update_balance(-total_cost)  # koszty
                    save_products(products)
                    save_finance(finance)
                    return f"Zamówiono {quantity} sztuk {product_name}"
                else:
                    return "Niewystarczające środki na zamówienie."
        return "Produkt nie znaleziony."

    def sell_product(self, product_name, quantity):
        products = load_products()
        finance = load_finance()
        for product in products:
            if product.name == product_name:
                try:
                    revenue = product.sell_product(quantity)
                    finance.update_balance(revenue)  # przychód
                    save_products(products)
                    save_finance(finance)
                    return f"Sprzedano {quantity} sztuk {product_name}"
                except ValueError as e:
                    return str(e)
        return "Produkt nie znaleziony."

def load_users(filepath="data/users.json"):
    with open(filepath, "r") as file:
        return [
            Admin(**data) if data["role"] == "admin" else Employe(**data)
            for data in json.load(file)
        ]

def save_users(users, filepath="data/users.json"):
    with open(filepath, "w") as file:
        json.dump([user.to_dict() for user in users], file, indent=4)