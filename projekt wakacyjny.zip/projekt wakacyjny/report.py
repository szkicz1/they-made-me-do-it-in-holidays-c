from user import load_users
from product import load_products
from finance import load_finance

def generate_report():
    users = load_users()
    products = load_products()
    finance = load_finance()

    report_content = "Raport Firmy\n\n"
    report_content += f"Stan Finansów: {finance.balance}\n\n"
    report_content += "Lista Użytkowników:\n"
    for user in users:
        report_content += f"- {user.username}, rola: {user.role}\n"

    report_content += "\nLista Produktów:\n"
    for product in products:
        report_content += f"- {product.name}, cena: {product.price}, ilość: {product.stock}\n"

    with open("data/report.txt", "w", encoding="utf-8") as file:
        file.write(report_content)