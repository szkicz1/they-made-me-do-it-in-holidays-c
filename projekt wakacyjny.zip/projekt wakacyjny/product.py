import json

class Product:
    def __init__(self, name, price, stock):
        self.name = name
        self.price = price
        self.stock = stock

    def to_dict(self):
        return {"name": self.name, "price": self.price, "stock": self.stock}

    def update_stock(self, quantity):
        self.stock += quantity

    def sell_product(self, quantity):
        if self.stock >= quantity:
            self.stock -= quantity
            return self.price * quantity  # zwraca przychód
        else:
            raise ValueError("Niewystarczający stan magazynowy")

def load_products(filepath="data/products.json"):
    with open(filepath, "r") as file:
        return [Product(**data) for data in json.load(file)]

def save_products(products, filepath="data/products.json"):
    with open(filepath, "w") as file:
        json.dump([product.to_dict() for product in products], file, indent=4)